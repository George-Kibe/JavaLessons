package com.emTech.TreasuryProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TreasuryProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
